#!/bin/bash
echo ""
echo "  123 Mobile Track — Tracker Firmware Flasher"
echo "  ─────────────────────────────────────────────"
echo ""
echo "  1. Plug the tracker in via USB"
echo "  2. Press Enter when ready"
echo ""
read -r

# Install esptool silently if not present
if ! python3 -m esptool version &>/dev/null 2>&1; then
  echo "  Installing esptool..."
  pip3 install esptool --quiet
fi

# Auto-detect the USB serial port
PORT=$(ls /dev/cu.usbserial-* 2>/dev/null | head -1)
if [ -z "$PORT" ]; then
  PORT=$(ls /dev/cu.SLAB_USBtoUART* 2>/dev/null | head -1)
fi
if [ -z "$PORT" ]; then
  echo ""
  echo "  Could not auto-detect the tracker. Available ports:"
  ls /dev/cu.* 2>/dev/null || echo "  (none found)"
  echo ""
  echo "  Enter the port (e.g. /dev/cu.usbserial-12345):"
  read -r PORT
fi

echo ""
echo "  Flashing to $PORT ..."
echo ""
python3 -m esptool --port "$PORT" --chip esp32 --baud 921600 \
  write_flash 0x10000 firmware.bin

echo ""
echo "  Done! The tracker will restart and come online automatically."
echo ""
