123 Mobile Track — Tracker Firmware v0.9.2
================================================

WHAT YOU NEED
  - The tracker (LilyGo T-SIM7000G)
  - A USB cable (USB-C or Micro-USB depending on your board)
  - Python 3 installed (https://www.python.org/downloads/)

HOW TO FLASH

  Mac / Linux:
    1. Open Terminal
    2. cd into this folder
    3. Run:  bash flash_mac.sh
    4. Follow the prompts

  Windows:
    1. Open this folder
    2. Double-click flash_windows.bat
    3. Follow the prompts
    4. When asked for the COM port, check Device Manager
       under "Ports (COM & LPT)" while the tracker is plugged in

AFTER FLASHING
  The tracker restarts automatically and will appear online
  in the 123 Mobile Track dashboard within about 60 seconds.
  Future firmware updates will happen automatically over the air —
  no USB cable needed again.

