@echo off
echo.
echo   123 Mobile Track -- Tracker Firmware Flasher
echo   ---------------------------------------------
echo.
echo   1. Plug the tracker in via USB
echo   2. Press any key when ready
echo.
pause > nul

pip install esptool --quiet 2>nul || pip3 install esptool --quiet 2>nul

echo.
echo   Detecting port...
echo.

REM List available COM ports for the user to identify
python -m serial.tools.list_ports 2>nul

echo.
set /p PORT="  Enter the COM port (e.g. COM3): "

echo.
echo   Flashing to %PORT% ...
echo.
python -m esptool --port %PORT% --chip esp32 --baud 921600 write_flash 0x10000 firmware.bin

echo.
echo   Done! The tracker will restart and come online automatically.
echo.
pause
